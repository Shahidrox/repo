CREATE USER postgres;
ALTER USER postgres WITH SUPERUSER login password 'password';